(
    (
        "Which mountain is more likely to be windy?",
        """
        (a) Both mountains are equally likely to be windy.
        (b) [color_common2] mountain.
        (c) [color_common1] mountain.
        """,
        'a',
        'c'
    ),
    (
        "Which carpet is more likely to experience strong wind?",
        """
        (a) The carpet enchanted to go to [color_common1] mountain.
        (b) The carpet enchanted to go to [color_common2] mountain.
        (c) Either carpet is equally likely to experience strong wind.
        """,
        'c',
        'c'
    ),
    (
        "Which carpet is more likely to go to [color_common2] Mountain?",
        """
        (a) The carpet on the left.
        (b) The carpet with the symbol that means “[color_common2] Mountain” written on it.
        (c) The carpet on the right.
        """,
        'b',
        'c'
    ),
    (
        "Where are you more likely to get a gold coin?",
        """
        (a) On [color_common2] Mountain.
        (b) It depends on each genie’s interest in music.
        (c) On [color_common1] Mountain.
        """,
        'b',
        'c'
    ),
    (
        "How can you tell when a genie is interested in music?",
        """
        (a) When a genie is interested in music, he looks different.
        (b) When a genie is interested in music, his lamp glows brighter.
        (c) Genies that are more interested in music will often come out of their lamps and listen to a song.
        """,
        'c',
        'c'
    ),
    (
        "How does a genie’s interest in music affect the other genies?",
        """
        (a) When one genie on a mountain is interested in music, the other one isn’t.
        (b) Each genie has his own interests and one genie’s interest in music doesn’t affect the other genies.
        (c) When one genie on a mountain is interested in music, the other one is too.
        """,
        'b',
        'c'
    ),
    (
        "How does the wind affect the genies’ interest in music?",
        """
        (a) Genies are more interested in music on windy days.
        (b) Genies live inside lamps, so they don’t care about the wind outside.
        (c) Genies are more interested in music on days without wind.
        """,
        'b',
        'c'
    ),
)
